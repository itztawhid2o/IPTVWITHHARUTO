<h1>Spain VOD</h1>

<h2>Yowi TV</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | HQM Arabic| [>](https://livelist01.yowi.tv/lista/39596c72840d27b213caf4e58c39599a6f2ed203/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/arabic-hqm-logo.png"/> | HQMArabic.es |
| 2   | HQM Baladas| [>](https://livelist01.yowi.tv/lista/5d7d2c21e0ec7a8a99fd1fdbc52cbdc0782f77fc/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/baladas-hqm-logo.png"/> | HQMBaladas.es |
| 3   | HQM Blues| [>](https://livelist01.yowi.tv/lista/81c601f370e44dc566113fd752204be5f5f53b61/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/blues-hqm-logo.png"/> | HQMBlues.es |
| 4   | HQM Chill Out| [>](https://livelist01.yowi.tv/lista/183a351ddb0e57af6d735256226e6033c32219ab/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/chill-out-hqm-logo.png"/> | HQMChillOut.es |
| 5   | HQM Classic| [>](https://livelist01.yowi.tv/lista/f04129475945936b248aa723de56519ea2ff10fc/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/classic-hqm-logo.png"/> | HQMClassic.es |
| 6   | HQM Dance| [>](https://livelist01.yowi.tv/lista/57cf2f51b07ff21988a7a6f0270a66d41086d4a4/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/dance-hqm-logo.png"/> | HQMDance.es |
| 7   | HQM Folk| [>](https://livelist01.yowi.tv/lista/9f5310c179e8e840188d183be235f755b18cf703/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/folk-hqm-logo.png"/> | HQMFolk.es |
| 8   | HQM Gym| [>](https://livelist01.yowi.tv/lista/abb87f329d0ed03072b1930e9636a53e8076c8d5/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/gym-hqm-logo.png"/> | HQMGym.es |
| 9   | HQM Hip Hop| [>](https://livelist01.yowi.tv/lista/8327abc87895df4c76db1155435fdca6a3607bbd/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/hip-hop-hqm-logo.png"/> | HQMHipHop.es |
| 10   | HQM Hits| [>](https://livelist01.yowi.tv/lista/5e2db2017a8fd03f73b40ede363d1a586db4e9a6/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/hits-hqm-logo.png"/> | HQMHits.es |
| 11   | HQM Jazz| [>](https://livelist01.yowi.tv/lista/f204aa5b3f0691e69851b54b7746ef09ede26f6a/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/jazz-hqm-logo.png"/> | HQMJazz.es |
| 12   | HQM Kids| [>](https://livelist01.yowi.tv/lista/e4bc12dafe33c3ceb3e382e3acc0ec2c012cf7fd/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/kids-hqm-logo.png"/> | HQMKids.es |
| 13   | HQM Latin| [>](https://livelist01.yowi.tv/lista/9a4da7871ec57b4b63ed49597a13d09869172be0/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/latin-hqm-logo.png"/> | HQMLatin.es |
| 14   | HQM Pop| [>](https://livelist01.yowi.tv/lista/eb2fa68a058a701fa5bd2c80f6c8a6075896f71d/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/pop-hqm-logo.png"/> | HQMPop.es |
| 15   | HQM Relax| [>](https://livelist01.yowi.tv/lista/dc1b71c6fda2e687050facaa7242062cbf5a7f2a/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/relax-hqm-logo.png"/> | HQMRelax.es |
| 16   | HQM Remember | [>](https://livelist01.yowi.tv/lista/57c98e2e295a0b69b52dc5f84edc4b1b68783ba2/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/remember-hqm-logo.png"/> | HQMRemember.es |
| 17   | HQM Rock| [>](https://livelist01.yowi.tv/lista/0d6c7ccfac89946bfd41ae34c527e8d94734065c/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/rock-hqm-logo.png"/> | HQMRock.es |
| 18   | HQM Spanish | [>](https://livelist01.yowi.tv/lista/8635ae40f8d1a32eccd63d1f58b55662c9c98f9f/master.m3u8) | <img height="20" src="https://hqm.es/wp-content/uploads/spanish-hqm-logo.png"/> | HQMSpanish.es |
