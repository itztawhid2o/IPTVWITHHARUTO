<h1>Ukraine</h1>

<h2>DVB-T2 (Zeonbud)</h2>

* http://www.zeonbud.com.ua/perechen_telekanal_ukr.html
* https://uk.wikipedia.org/wiki/Цифрове_наземне_телебачення_в_Україні#Перелік_загальнонаціональних_цифрових_телеканалів

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Pershyi Ⓢ | [>](http://149.5.17.34:20041/play/a068) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Pershyi_%282022%29.svg/640px-Pershyi_%282022%29.svg.png"/> | UAFirst.ua |
| 2   | Rada TV Ⓢ | [>](http://149.5.17.34:20041/play/a07b) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7b/Rada_TV_%282021%29.svg/512px-Rada_TV_%282021%29.svg.png"/> | RadaTV.ua |
| 3   | 1+1 | [>](http://149.5.17.34:20041/play/a06d) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/1%2B1_logo.svg/640px-1%2B1_logo.svg.png"/> | 1Plus1.ua |
| 4   | Suspilne Kultura | [>](https://ext.cdn.nashnet.tv/228.0.0.141/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Suspilne_Kultura_%282022%29.svg/640px-Suspilne_Kultura_%282022%29.svg.png"/> | SuspilneKultura.ua |
| 5   | ICTV Ⓢ | [>](http://91.210.251.166:4504/udp/239.0.2.21:4000) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/ICTV_2017_horizontal.svg/640px-ICTV_2017_horizontal.svg.png"/> | ICTV.ua |
| 6   | STB | [>](http://cdnua03.hls.tv/133/hls/37a7d70ef2fcf08bcd712e4397c7d5c9/4592/stream.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/STB_logo.svg/868px-STB_logo.svg.png"/> | STB.ua |
| 7   | Inter | [>](http://149.5.17.34:20041/play/a05g) | <img height="20" src="https://i.imgur.com/R06gbuT.png"/> | Inter.ua |
| 8   | UNIAN TV | [>](http://149.5.17.34:20041/play/a06s) | <img height="20" src="https://i.imgur.com/Alu78zn.png"/> | UNIANTV.ua |
| 9   | Bigudi | [>](http://149.5.17.34:20041/play/a06h) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Bigudi_%28Ukraine%29_%281-st_logo%29.svg/627px-Bigudi_%28Ukraine%29_%281-st_logo%29.svg.png"/> | Bigudi.ua |
| 10  | Армія ТБ | [>](http://91.210.251.166:4535/udp/239.0.2.74:4000) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f8/ArmyTV_logo_%282023%29.svg/640px-ArmyTV_logo_%282023%29.svg.png"/> | ArmyTV.ua |
| 11  | Novyi Kanal Ⓢ | [>](rtmp://93.189.60.202//935) | <img height="20" src="https://i.imgur.com/4JhqpPM.png"/> | NovyKanal.ua |
| 12  | TET Ⓢ | [>](http://149.5.17.34:20041/play/a06f) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/TET_logo.svg/640px-TET_logo.svg.png"/> | TET.ua |
| 13  | 2+2 Ⓢ | [>](http://185.235.187.10:8888/play/2plus2/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/2%2B2_logo_2017.svg/640px-2%2B2_logo_2017.svg.png"/> | 2Plus2.ua |
| 14  | M1 Ⓢ | [>](http://185.235.187.11:8888/play/m1/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/M1_%28Ukraine%29_%282001-2021%29.svg/768px-M1_%28Ukraine%29_%282001-2021%29.svg.png"/> | M1.ua |
| 15  | NTN | [>](http://185.235.187.11:8888/play/ntn/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/NTNUA_logo_%282013%29.svg/640px-NTNUA_logo_%282013%29.svg.png"/> | NTN.ua |
| 16   | Mega | [>](http://149.5.17.34:20041/play/a05k) | <img height="20" src="https://i.imgur.com/F1v69tn.png"/> | Mega.ua |
| 17   | ПлюсПлюс Ⓢ | [>](http://185.235.187.11:8888/play/a00t/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/PLUSPLUSUA.svg/640px-PLUSPLUSUA.svg.png"/> | PlusPlus.ua |
| 18   | Ми — Україна Ⓢ | [>](http://149.5.17.34:20041/play/a06x) | <img height="20" src="https://i.imgur.com/nkatL7Q.png"/> | MyUkrainaTV.ua |
| 19   | 1+1 Україна Ⓢ | [>](http://149.5.17.34:20041/play/a00s) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1f/1%2B1_Ukraina_%282022%29.svg/640px-1%2B1_Ukraina_%282022%29.svg.png"/> | 1Plus1Ukraine.ua |
| 20   | ICTV2 | [>](http://46.18.107.105:9999/channel/n5ef91f61/index.mpeg?q=34f3e508660e39f2f68068dd1c8f4604) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/28/ICTV_2_%282022%29.svg/640px-ICTV_2_%282022%29.svg.png"/> | ICTV2.ua |
| 21   | ОЦЕ ТБ Ⓢ | [>](http://185.235.187.11:8888/play/a039/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/OCE_logo_%282017%29.svg/640px-OCE_logo_%282017%29.svg.png"/> | Oce.ua |
| 22   | K1 | [>](http://149.5.17.34:20041/play/a05m) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/K1_Logo_2014.svg/655px-K1_Logo_2014.svg.png"/> | K1.ua |
| 23   | K2 | [>](http://149.5.17.34:20041/play/a05o) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/K2_logo_%282016%29.svg/640px-K2_logo_%282016%29.svg.png"/> | K2.ua |
| 24   | Zoom | [>](http://149.5.17.34:20041/play/a05q) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/ZoomUA_logo_%282015%29.svg/640px-ZoomUA_logo_%282015%29.svg.png"/> | Zoom.ua |
| 25   | Priamyi Ⓢ | [>](http://149.5.17.34:20041/play/a061) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/Pryamiy_2020.svg/624px-Pryamiy_2020.svg.png"/> | Pryamyy.ua |
| 26   | Espreso TV Ⓢ | [>](http://149.5.17.34:20041/play/a066) | <img height="20" src="https://i.imgur.com/xNatV8K.png"/> | EspresoTV.ua |
| 27   | XSport Ⓢ | [>](http://91.210.251.166:4858/udp/239.0.2.89:4000) | <img height="20" src="https://i.imgur.com/CHDcfrT.png"/> | XSport.ua |
| 28   | Enter-Film | [>](http://149.5.17.34:20041/play/a078) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Enter-FilmUA_%282013%29.png/819px-Enter-FilmUA_%282013%29.png"/> | EnterFilm.ua |
| 29   | Piksel TV | [>](https://ext.cdn.nashnet.tv/228.0.0.8/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/PixelUalogo.svg/640px-PixelUalogo.svg.png"/> | PikselTV.ua |
| 31   | 5 Kanal | [>](http://portal.ott.pink/watch/7/video.m3u8?geo=auto&token=CFEADF9789D77A45B3B359EE168CCCA6) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Logo_5_Channel.svg/480px-Logo_5_Channel.svg.png"/> | 5Kanal.ua |
| 32   | TAK TV | [x]() | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/e/ef/%D0%A2%D0%90%D0%9A_TV.png"/> | TakTV.ua |
| 33   | Сонце Ⓢ | [>](http://149.5.17.34:20041/play/a015) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/SonceUA_logo.svg/739px-SonceUA_logo.svg.png"/> | Sonce.ua |

<h2>1+1 Video</h2>

* https://1plus1.video/tvguide/uafirst/online

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 5   | Comedy Central Ukraine Ⓢ | [>](http://91.210.251.166:4550/udp/239.0.2.30:4000) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Comedy_Central_2018.svg/1024px-Comedy_Central_2018.svg.png"/> | ComedyCentralUkraine.ua |
| 7   | Kvartal TV Ⓢ | [>](rtmp://93.189.60.202//932) | <img height="20" src="https://i.imgur.com/6ZYWizP.png"/> | KvartalTV.ua |
| 14  | Суспільне Новини Ⓢ | [x](https://www.tvkaista.net/stream-forwarder/get.php?x=SuspilneNovyny) | <img height="20" src="https://i.imgur.com/6ZTGMli.png"/> | SuspilneNovyny.ua |
| 15  | Суспільне Крим Ⓢ | [>](https://ext.cdn.nashnet.tv/228.0.0.71/index.m3u8) | <img height="20" src="https://i.imgur.com/m7znCes.png"/> | SuspilneKrym.ua |

<h2>Kyivstar TV</h2>

* https://tv.kyivstar.ua/ua/live-channels/55efdb72e4b0781039bc0340-pershij-hd

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | 24 канал | [>](http://streamvideol1.luxnet.ua/news24/smil:news24.stream.smil/chunklist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/24_Kanal_logo.svg/768px-24_Kanal_logo.svg.png"/> | Channel24.ua |
| 0   | Рибалка | [>](http://91.210.251.166:4582/udp/239.0.2.104:4000) | <img height="20" src="https://i.imgur.com/NafW0xT.png"/> | Rybalka.ua |
| 0   | Київ Ⓢ | [>](rtmp://93.189.60.202//1040) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Kyiv_TV_%282023%29.svg/1024px-Kyiv_TV_%282023%29.svg.png"/> | Kyiv.ua |
| 0   | FREEДОМ Ⓢ | [>](http://portal.ott.pink/watch/7431/video.m3u8?geo=auto&token=CFEADF9789D77A45B3B359EE168CCCA6) | <img height="20" src="https://i.imgur.com/38UPLa9.png"/> | Freedom.ua |

<h2>Regional (Suspilne)</h2>

* [https://uk.wikipedia.org/wiki/Цифрове_наземне_телебачення_в_УкраїніMX-5_(DVB-T2)_(регіональні,_канали_мовлення_залежать_від_регіону)[12]](https://uk.wikipedia.org/wiki/%D0%A6%D0%B8%D1%84%D1%80%D0%BE%D0%B2%D0%B5_%D0%BD%D0%B0%D0%B7%D0%B5%D0%BC%D0%BD%D0%B5_%D1%82%D0%B5%D0%BB%D0%B5%D0%B1%D0%B0%D1%87%D0%B5%D0%BD%D0%BD%D1%8F_%D0%B2_%D0%A3%D0%BA%D1%80%D0%B0%D1%97%D0%BD%D1%96#MX-5_(DVB-T2)_(%D1%80%D0%B5%D0%B3%D1%96%D0%BE%D0%BD%D0%B0%D0%BB%D1%8C%D0%BD%D1%96,_%D0%BA%D0%B0%D0%BD%D0%B0%D0%BB%D0%B8_%D0%BC%D0%BE%D0%B2%D0%BB%D0%B5%D0%BD%D0%BD%D1%8F_%D0%B7%D0%B0%D0%BB%D0%B5%D0%B6%D0%B0%D1%82%D1%8C_%D0%B2%D1%96%D0%B4_%D1%80%D0%B5%D0%B3%D1%96%D0%BE%D0%BD%D1%83)[12])

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Суспільне Київ | [>](http://portal.ott.pink/watch/7592/index.m3u8?geo=auto&token=CFEADF9789D77A45B3B359EE168CCCA6) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/Suspilne_Kyiv_%282022%29.svg/640px-Suspilne_Kyiv_%282022%29.svg.png"/> | SuspilneKyiv.ua |

<h2>Other</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 2   | 1 Odessa Ⓢ | [>](http://cdn1.live-tv.od.ua:8081/1tvod/1tvod-abr/playlist.m3u8) | <img height="20" src="https://i.imgur.com/9z2LnBg.png"/> |
| 3   | 34 Kanal Ⓢ | [>](https://streamvideol.luxnet.ua/34ua/34ua.stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/0buhFKQ.png"/> | 34Telekanal.ua |
| 4   | 7 Kanal | [>](http://cdn10.live-tv.od.ua:8081/7tvod/7tvod-abr/7tvod/7tvod/playlist.m3u8) | <img height="20" src="https://i.imgur.com/nJvGdoj.jpg"/> | 7kanal.ua |
| 5   | A1 Odessa | [>](http://cdn1.live-tv.od.ua:8081/a1od/a1od-abr/a1od/a1od-720p/playlist.m3u8) | <img height="20" src="https://i.imgur.com/0DUi5fO.jpg"/> |
| 6   | Arhat TB | [>](http://arhat.tv/public/720p/index.m3u8) | <img height="20" src="https://i.imgur.com/Qdgntk1.jpg"/> | ArhatTV.ua |
| 7   | ATR Ⓢ | [>](http://stream.atr.ua/atr/live/index.m3u8) | <img height="20" src="https://i.imgur.com/tKmYWYH.png"/> | ATR.ua |
| 8   | BamBarBia TV | [>](http://cdn1.live-tv.od.ua:8081/bbb/bbbtv-abr/bbb/bbbtv-720p/playlist.m3u8) | <img height="20" src="https://i.imgur.com/LIk85IA.png"/> | BamBarBiaTV.ua |
| 9   | BTB Ⓢ | [>](http://video.vtvplus.com.ua:81/hls/online/index.m3u8) | <img height="20" src="https://i.imgur.com/JG493Vn.png"/> |
| 10   | Che Pe Info Ⓢ | [>](http://109.68.40.67/life/magnolia_3/index.m3u8) | <img height="20" src="https://i.imgur.com/7Ycv3bL.png"/> | ChePeInfo.ua |
| 12   | Chernivtsi Promin | [>](http://langate.tv/promin/live_720/index.m3u8) | <img height="20" src="https://i.imgur.com/IbwmfzF.png"/> |
| 13   | CNL Europa Ⓢ | [>](http://live-mobile.cdn01.net/hls-live/202E1F/default/mobile/stream_10429_3.m3u8) | <img height="20" src="https://i.imgur.com/lozzdS7.png"/> |
| 14   | Duma TV | [>](http://cdn1.live-tv.od.ua:8081/dumska/dumska-abr/dumska/dumska720p/playlist.m3u8) | <img height="20" src="https://i.imgur.com/KlPqxlo.png"/> |
| 15   | GIT | [>](https://stream.uagit.tv/gittv.m3u8) | <img height="20" src="https://i.imgur.com/v5J8tiS.png"/> | GIT.ua |
| 16   | GTV | [>](http://cdn1.live-tv.od.ua:8081/a1od/gtvod-abr/a1od/gtvod-720p/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Rc6UGkb.jpg"/> | GTV.ua |
| 17   | HTK | [>](http://stream.ntktv.ua/s/ntk/ntk.m3u8) | <img height="20" src="https://i.imgur.com/on0TfJ6.png"/> |
| 19   | ID Fashion | [>](https://idfashion.cdn-02.cosmonova.net.ua/hls/idfashion_ua_hi/index.m3u8?_=1602581479) | <img height="20" src="https://i.imgur.com/Y50tmIN.png"/> | IDFashion.ua |
| 21   | Izmail TV Ⓢ | [>](https://cdn10.live-tv.od.ua:8083/izod/izod-abr-lq/playlist.m3u8) | <img height="20" src="https://i.imgur.com/mpMjj7o.png"/> | IzmailTV.ua |
| 23   | Kratu Ⓢ | [>](https://cdn10.live-tv.od.ua:8083/kratu/kratu-abr-lq/kratu/kratu-sub/chunks.m3u8) | <img height="20" src="https://i.imgur.com/NXqO1Qa.png"/> |
| 24   | Lale Ⓢ | [>](http://stream.atr.ua/lale//live/index.m3u8) | <img height="20" src="https://i.imgur.com/Nv6P5Ds.png"/> | Lale.ua |
| 25   | M2 Ⓢ | [>](http://live.m2.tv/hls3/stream.m3u8) | <img height="20" src="https://i.imgur.com/IwUc4pC.png"/> | M2.ua |
| 26   | NTA | [>](http://95.67.106.10/hls/nta_ua_hi/index.m3u8) | <img height="20" src="https://i.imgur.com/AGzWPZv.png"/> |
| 27   | Olvia Sat Odessa | [>](http://cdn1.live-tv.od.ua:8081/ktkod/ktkod-abr/ktkod/ktkod/playlist.m3u8) | <img height="20" src="https://i.imgur.com/khlZ532.png"/> |
| 28   | Pershiy Zakhidniy Ⓢ | [>](http://hls.cdn.ua/1zahid.com_live/_definst_/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/yifGKcA.png"/> |
| 29   | Perviy Delovoy | [>](http://pershij-dlovij-hls3.cosmonova.net.ua/hls/pershij-dlovij_ua_hi/index.m3u8) | <img height="20" src="https://i.imgur.com/rIaWxpn.png"/> |
| 30   | Perviy Gorodskoy Krivoy | [>](http://cdn1.live-tv.od.ua:8081/1tvkr/1tvkr-abr/1tvkr/1tvkr/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Em3J7XO.jpg"/> |
| 31   | Perviy Gorodskoy Odessa | [>](http://91.194.79.46:8081/stream1/channel1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Em3J7XO.jpg"/> |
| 32   | Pravda TYT | [>](http://pravdatytkievshina-hls2.cosmonova.net.ua/hls/pravdatytkievshina_ua_hi/index.m3u8) | <img height="20" src="https://i.imgur.com/p5MSKuW.jpg"/> | PravdaTUT.ua |
| 33   | Pryamyi | [>](http://prm-hls1.cosmonova.net.ua/hls/prm_ua_hi/index.m3u8) | <img height="20" src="https://i.imgur.com/5rtPDpn.png"/> | Pryamyy.ua |
| 34   | Radio Suite | [>](http://stream1.luxnet.ua/luxstudio/smil:luxstudio.stream.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/pvf1LXW.png"/> |
| 35   | Rudana | [>](https://live.rudana.com.ua/hls/stream_FHD.m3u8) | <img height="20" src="https://i.imgur.com/mu81qSc.png"/> |
| 36   | Simon Ⓢ | [>](http://hls.simon.ua/live-HD/live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/RaVchcn.jpg"/> | Simon.ua |
| 37   | SK 1 Ⓢ | [>](https://cdn10.live-tv.od.ua:8083/sk1zt/sk1zt-abr-lq/playlist.m3u8) | <img height="20" src="https://i.imgur.com/wr0CN1l.png"/> | SK1.ua |
| 38   | Svarogichi | [>](http://tv.tv-project.com:1935/live/live1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/80bSn6j.png"/> |
| 39   | TBN | [>](http://62.32.67.187:1935/WEB_Ukraine24/Ukraine24.stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/DHwhdRF.png"/> | TBNUkraine.us |
| 40   | TIS TV Ⓢ | [>](http://cdn10.live-tv.od.ua:8081/riood/tisod-abr/riood/tisod504/playlist.m3u8) | <img height="20" src="https://i.imgur.com/aC01GvC.png"/> | TISTV.ua |
| 41   | Treti Cifrovoj Ⓢ | [>](http://cdn1.live-tv.od.ua:8081/3tvod/3tvod-abr/3tvod/3tvod/playlist.m3u8) | <img height="20" src="https://i.imgur.com/nwRBxTR.png"/> | TretiyCifrovoy.ua |
| 42   | Trofey Ⓢ | [>](https://5db1ab4f970be.streamlock.net/live/smil:trofey.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/3LSDHHJ.png"/> | Trofey.ua |
| 43   | TV 5 Zaporozhye Ⓢ | [>](http://rtsp.cdn.ua/tv5.zp.ua_live/_definst_/mp4:tv5/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ixKcTad.png"/> |
| 44   | TVA Czernowitz Ⓢ | [>](http://hls.cdn.ua/tva.ua_live/_definst_/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/bUz2IP9.png"/> |
| 45   | Yuzhnaya Volna | [>](http://cdn1.live-tv.od.ua:8081/wave/wave-abr/playlist.m3u8) | <img height="20" src="https://i.imgur.com/8gSP6aH.png"/> | YuzhnayaVolnaTV.ua |
| 46   | Zdorovood TV Odessa Ⓢ | [>](http://cdn1.live-tv.od.ua:8081/zdorovood/zdorovo-abr-lq/zdorovood/zdorovo/playlist.m3u8) | <img height="20" src="https://i.imgur.com/VqDD7OE.png"/> |
| 47   | Z Zaporozhye | [>](https://stream.ztv.zp.ua/hls/live.m3u8) | <img height="20" src="https://i.imgur.com/f0nOjL8.png"/> |
