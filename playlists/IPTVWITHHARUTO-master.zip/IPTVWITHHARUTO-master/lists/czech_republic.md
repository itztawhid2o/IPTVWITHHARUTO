<h1>Czech Republic</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | ČT1 Ⓖ    | [>](https://sktv.plainrock127.xyz/get.php?x=CT1) | <img height="20" src="https://i.imgur.com/qBlEbN3.png"/> | CT1.cz |
| 2   | ČT2 Ⓖ    | [>](https://sktv.plainrock127.xyz/get.php?x=CT2) | <img height="20" src="https://i.imgur.com/HpnGC6A.png"/> | CT2.cz |
| 3   | ČT24      | [>](https://sktv.plainrock127.xyz/get.php?x=CT24) | <img height="20" src="https://i.imgur.com/pUMRFs1.png"/> | CT24.cz |
| 4   | ČT sport Ⓖ    | [>](https://sktv.plainrock127.xyz/get.php?x=CTsport) | <img height="20" src="https://i.imgur.com/I2dltZW.png"/> | CTSport.cz |
| 5   | ČT :D      | [>](https://sktv.plainrock127.xyz/get.php?x=CT_D) | <img height="20" src="https://i.imgur.com/Pa5rLpA.png"/> | CTDecko.cz |
| 6   | ČT art      | [>](https://sktv.plainrock127.xyz/get.php?x=CTart) | <img height="20" src="https://i.imgur.com/u8mfETB.png"/> | CTart.cz |
| 7   | ČT sport Plus Ⓖ    | [>](https://sktv.plainrock127.xyz/get.php?x=CTsportPlus) | <img height="20" src="https://i.imgur.com/5JiMynW.png"/> | |
| 8   | JOJ Family Ⓢ    | [>](https://live.cdn.joj.sk/live/hls/family-540.m3u8) | <img height="20" src="https://i.imgur.com/IZHIAAj.png"/> | JojFamily.sk |
| 9   | Šlágr Originál Ⓢ    | [>](https://stream-6.mazana.tv/slagr.m3u) | <img height="20" src="https://i.imgur.com/fQcx9S2.png"/> | SlagrOriginal.cz |
| 10  | Šlágr Muzika Ⓢ    | [>](https://stream-33.mazana.tv/slagr2.m3u) | <img height="20" src="https://i.imgur.com/J9YHDVS.png"/> | SlagrMuzika.cz |
| 11  | Šlágr Premium Ⓢ    | [>](https://stream-15.mazana.tv/slagrpremium.m3u) | <img height="20" src="https://i.imgur.com/Lp0IqDx.png"/> | SlagrPremium.cz |
| 12  | Prima Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_family/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/0aHT2Nj.png"> | Prima.cz |
| 13  | CNN Prima News   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_cnn/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/Il7t0bU.png"> | CNNPrimaNews.cz |
| 14  | Prima Zoom Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_zoom/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/zuzBucZ.png"> | PrimaZoom.cz |
| 15  | Prima Love Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_love/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/TOCZc3Y.png"> | PrimaLove.cz |
| 16  | Prima STAR Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_star/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/tQGwvNs.png"> | PrimaStar.cz |
| 17  | Prima Krimi Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_krimi/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/Dn2YxrA.png"> | PrimaKrimi.cz |
| 18  | Prima MAX Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_max/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/QaEakvm.png"> | PrimaMax.cz |
| 19  | Prima Cool Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_cool/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/JMHWmcJ.png"> | PrimaCool.cz |
| 20  | Prima Show Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_show/playlist/cze/live_hd.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/zX4NTJ5.png"> | PrimaShow.cz |
| 21  | Óčko Ⓢ    | [>](https://ocko-live.ssl.cdn.cra.cz/channels/ocko/playlist.m3u8) | <img height="20" src="https://i.imgur.com/iPmpsnN.png"/> | Ocko.cz |
| 22  | Óčko Star Ⓢ    | [>](https://ocko-live.ssl.cdn.cra.cz/channels/ocko_gold/playlist.m3u8) | <img height="20" src="https://i.imgur.com/tGzQFWw.png"/> | OckoStar.cz |
| 23  | Óčko Expres Ⓢ    | [>](https://ocko-live.ssl.cdn.cra.cz/channels/ocko_expres/playlist.m3u8) | <img height="20" src="https://i.imgur.com/e731JNS.png"/> | OckoExpres.cz |
| 24  | Retro Music Television Ⓢ    | [>](https://stream.mediawork.cz/retrotv/smil:retrotv2.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/a6S2Yo4.png"/> | RetroMusicTV.cz |
| 25  | TN Live      | [>](https://sktv.plainrock127.xyz/get.php?x=NovaTNLive) | <img height="20" src="https://i.imgur.com/9P7ZyFu.png"/> | |
| 26  | Praha TV      | [>](https://stream.polar.cz/prahatv/prahatvlive-1/playlist.m3u8) | <img height="20" src="https://www.praga2018.cz/wp-content/uploads/logo-prahatv.png"/> | PrahaTV.cz |
| 27  | TV Nova Ⓢ    | [>](https://sktv.plainrock127.xyz/get.php?x=Nova) | <img height="20" src="https://i.imgur.com/77ztmd9.png"/> | tvnova.cz |
| 28  | Východoceská TV      | [>](https://stream.polar.cz/vctv/vctvlive-1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/4Wwptd3.png"/> | V1.cz |
| 29  | UTV (Czech Republic)      | [>](https://vysilani.zaktv.cz/broadcast/hls/utv/index.m3u8) | <img height="20" src="https://imgur.com/ulfeIwM.png"/> | utv.cz |