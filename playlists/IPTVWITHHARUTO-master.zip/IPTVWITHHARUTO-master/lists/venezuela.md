<h1>Venezuela</h1>

https://en.wikipedia.org/wiki/List_of_television_networks_in_Venezuela

| #   | Channel         | Link  | Logo | EPG id |
|:---:|:---------------:|:-----:|:----:|:------:|
| 1   | Venevisión      | [>](https://venevision.akamaized.net/hls/live/2098814/VENEVISION/master.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0a/Logotipo_de_Venevisi%C3%B3n.svg/641px-Logotipo_de_Venevisi%C3%B3n.svg.png"/> | Venevision.ve |
| 2   | Venezolana de Televisión Ⓓ | [>](https://www.dailymotion.com/embed/video/x828i6j) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Venezolana_de_Televisi%C3%B3n_2018.svg/640px-Venezolana_de_Televisi%C3%B3n_2018.svg.png"/> | VenezolanadeTelevision.ve |
| 3   | TVes            | [x](https://ls.tves.gob.ve/hls/tves.m3u8) | <img height="20" src="https://i.imgur.com/QX5DVUB.png"/> | TVes.ve |
| 4   | Televen         | [>](https://setp-televen-ssai-mslv4-open.akamaized.net/hls/live/2107128/televen/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/c/c0/Televen_logo.PNG"/> | Televen.ve |
| 6   | Globovisión     | [>](https://vcp5.myplaytv.com/globovision/globovision/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/4/47/Globovisi%C3%B3n_logo_2013.png"/> | Globovision.ve |
| 7   | Vale TV Ⓢ       | [>](https://vcp2.myplaytv.com/valetv/valetv/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/9/98/Logo_de_VALE_TV.png"/> | ValeTV.ve |
| 9   | Telesur         | [>](https://raw.githubusercontent.com/BellezaEmporium/IPTV_Exception/master/channels/ve/telesur.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/8/82/TeleSUR.png"/> | TeleSUR.ve |
