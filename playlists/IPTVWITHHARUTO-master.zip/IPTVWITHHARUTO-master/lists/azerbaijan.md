<h1>Azerbaijan</h1>

* https://az.wikipedia.org/wiki/Azərbaycan_televiziya_kanallarının_siyahısı

<h2>DVB-S</h2>

* https://www.lyngsat.com/freetv/Azerbaijan.html

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | ARB 24 | [>](http://85.132.81.184:8080/arb/live/index.m3u8) | <img height="20" src="https://i.imgur.com/mtvIFyq.png"/> | ARB24.az |
| 0   | ARB Günəş Ⓢ | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=ARMGunes) | <img height="20" src="https://i.imgur.com/dSg7KUK.png"/> | ArbGunes.az |
| 0   | ARB Ⓢ | [>](http://109.205.166.68/server124/arb/index.m3u8) | <img height="20" src="https://i.imgur.com/E97M2OL.png"/> | ARB.az |
| 0   | Azad TV Ⓢ | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=ATVAz) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/ATV_%282012-h.h.%29.png/474px-ATV_%282012-h.h.%29.png"/> | AzadTV.az |
| 0   | AzStarTV | [>](http://live.azstartv.com/azstar/smil:azstar.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/di3XX5L.png"/> | AzStarTV.ca |
| 0   | AZTV Ⓢ | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=AZTV) | <img height="20" src="https://i.imgur.com/snBMMeH.png"/> | AZTV.az |
| 0   | Baku TV | [>](https://rtmp.baku.tv/live/bakutv_720p.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Baku_TV_%282018%29.png/640px-Baku_TV_%282018%29.png"/> | BakuTV.az |
| 0   | CBC | [>](https://stream.cbctv.az:5443/LiveApp/streams/cbctv.m3u8) | <img height="20" src="https://i.imgur.com/wVT0dwO.png"/> | CBC.az |
| 0   | CBC Sport Ⓖ | [>](https://mn-nl.mncdn.com/cbcsports_live/cbcsports/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/az/0/04/CBC_Sport_TV_loqo.png"/> | CBCSport.az |
| 0   | Dünya TV Ⓢ | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=Dunya) | <img height="20" src="https://upload.wikimedia.org/wikipedia/az/5/5d/D%C3%BCnya_TV_%282019-h.h.%29.png"/> | DunyaTV.az |
| 0   | İctimai TV Ⓢ | [>](http://109.205.166.68/server124/ictimai_tv/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/%C4%B0ctimai_TV_%282021-h.h.%29.svg/470px-%C4%B0ctimai_TV_%282021-h.h.%29.svg.png"/> | IctimaiTV.az |
| 0   | İdman TV Ⓢ | [>](http://109.205.166.68/server124/idman_az/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/az/thumb/8/88/%C4%B0dman_Az%C9%99rbaycan_TV_loqo_%282019-h.h.%29.png/640px-%C4%B0dman_Az%C9%99rbaycan_TV_loqo_%282019-h.h.%29.png"/> | IdmanTV.az |
| 0   | Kanal S | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=KanalS) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Kanal_S_%282022%29.png/616px-Kanal_S_%282022%29.png"/> | KanalS.az |
| 0   | Mədəniyyət TV Ⓢ | [>](https://str.yodacdn.net/medeniyyet/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/f/fc/M%C9%99d%C9%99niyy%C9%99t_TV_logo.png"/> | MedeniyyetTV.az |
| 0   | Muz TV | [x]() | <img height="20" src="https://i.imgur.com/CjySP1V.png"/> | MuzTV.az |
| 0   | Real TV | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=RealTV) | <img height="20" src="https://i.imgur.com/e2KFL0R.png"/> | RealTV.az |
| 0   | Space TV Ⓢ | [>](http://109.205.166.68/server124/space_tv/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Space_TV_loqosu_%282023-h.h.%29.png/296px-Space_TV_loqosu_%282023-h.h.%29.png"/> | SpaceTV.az |
| 0   | TMB Azərbaycan | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=TMBAzerbaijan) | <img height="20" src="https://upload.wikimedia.org/wikipedia/az/c/c2/TMB_TV_loqosu.png"/> |
| 0   | Topaz 2 | [x]() | <img height="20" src="https://www.lyngsat.com/logo/tv/tt/topaz_tv_az.png"/> |
| 0   | Xəzər Xəbər | [x]() | <img height="20" src="https://i.imgur.com/AuB8bnq.png"/> | XezerXeber.az |

<h2>myvideo.az</h2>

* http://myvideo.az/channels.aspx

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Xəzər TV Ⓢ | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=Xezer) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/a/a5/X%C9%99z%C9%99r_TV_%282023%29.png"/> | XezerTV.az |
| 0   | Səhiyyə TV | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=SehiyyeTV) | <img height="20" src="https://upload.wikimedia.org/wikipedia/az/thumb/c/cd/S%C9%99hiyy%C9%99_TV.png/640px-S%C9%99hiyy%C9%99_TV.png"/> | SehiyyeTV.az |
| 0   | MCJ TV SHOP | [x](https://www.tvkaista.net/stream-forwarder/get.php?x=MCJTVShop) | <img height="20" src="https://tvtolive.com/wp-content/uploads/MCJ-TV-Shop-tvtolive.com_.jpg"/> |
| 0   | VIP HD | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=AZ_VIP) | <img height="20" src="https://tvtolive.com/wp-content/uploads/VIP-TV-tvtolive.com_.jpg"/> |
| 0   | MTV Azerbaijan Ⓢ | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=MTVAzerbaijan) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/00/MTV_Az%C9%99rbaycan_%282022%29.png/622px-MTV_Az%C9%99rbaycan_%282022%29.png"/> | MTVAzerbaijan.az |
