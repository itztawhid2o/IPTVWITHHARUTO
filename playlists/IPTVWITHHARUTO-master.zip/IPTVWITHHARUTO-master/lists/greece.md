<h1>Greece</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1    | ERT 1        | [>](http://ert-live-bcbs15228.siliconweb.com/media/ert_1/ert_1medium.m3u8) | <img height="20" src="https://i.imgur.com/WWMe8IY.png"/> | ERT1.gr |
| 2    | ERT 2        | [>](http://ert-live-bcbs15228.siliconweb.com/media/ert_2/ert_2medium.m3u8) | <img height="20" src="https://i.imgur.com/pcusPFl.png"/> | ERT2.gr |
| 3    | ERT 3        | [>](http://ert-live-bcbs15228.siliconweb.com/media/ert_3/ert_3medium.m3u8) | <img height="20" src="https://i.imgur.com/KyhzDRm.png"/> | ERT3.gr |
| 4    | ANT1         | [>](https://antennalivesp-lh.akamaihd.net/i/live_1@715138/index_800_av-p.m3u8) | <img height="20" src="https://i.imgur.com/np0s1FN.png"/> | ANT1.gr |
| 5    | Star Ⓖ      | [>](https://livestar.siliconweb.com/media/star1/star1mediumhd.m3u8) | <img height="20" src="https://i.imgur.com/CJOtJlL.png"/> | StarChannel.gr |
| 6    | AlphaTV      | [>](https://alphalive-i.akamaihd.net/hls/live/682300/live/master.m3u8) | <img height="20" src="https://i.imgur.com/bAVGX0l.png"/> | AlphaTV.gr |
| 7    | Skai TV      | [>](https://skai-live.siliconweb.com/media/cambria4/index.m3u8) | <img height="20" src="https://i.imgur.com/TSg7B8X.png"/> | SkaiTV.gr |
| 8    | Open TV      | [>](https://liveopencloud.siliconweb.com/1/ZlRza2R6L2tFRnFJ/eWVLSlQx/hls/live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/T99OSnk.png"/> | OpenTV.gr |
| 9    | Makedonia TV | [x]() | <img height="20" src="https://i.imgur.com/6Ir6wcR.png"/> | MakedoniaTV.gr |
| 10   | Mega Channel | [x]() | <img height="20" src="https://i.imgur.com/zewcwLd.png"/> | MEGATVHD.gr |
| 11   | Kontra       | [>](http://kontralive.siliconweb.com/live/kontratv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/zMgczHY.png"/> | KontraChannel.gr |
| 12   | ERT World    | [>](http://ert-live-bcbs15228.siliconweb.com/media/ert_world/ert_worldmedium.m3u8) | <img height="20" src="https://i.imgur.com/RwrQKns.png"/> | ERTWorld.gr |
| 13   | ERT Sports 1  | [>](http://ert-live-bcbs15228.siliconweb.com/media/ert_sports/ert_sports.m3u8) | <img height="20" src="https://i.imgur.com/gebWmAB.png"/> | ERTSports1.gr |
| 14   | ERT Sports 2 | [>](http://ert-live-bcbs15228.siliconweb.com/media/ert_sports_2/ert_sports_2medium.m3u8) | <img height="20" src="https://i.imgur.com/gebWmAB.png"/> | ERTSports2.gr |
| 15   | ERT Sports 3 | [>](http://ert-live-bcbs15228.siliconweb.com/media/ert_sports_3/ert_sports_3medium.m3u8) | <img height="20" src="https://i.imgur.com/gebWmAB.png"/> | ERTSports3.gr |
| 15   | ERT Sports 4 | [>](http://ert-live-bcbs15228.siliconweb.com/media/ert_sports_4/ert_sports_4medium.m3u8) | <img height="20" src="https://i.imgur.com/gebWmAB.png"/> |
| 15   | ERT Sports 5 | [>](http://ert-live-bcbs15228.siliconweb.com/media/ert_sports_5/ert_sports_5medium.m3u8) | <img height="20" src="https://i.imgur.com/gebWmAB.png"/> |
| 15   | ERT Sports 6 | [>](http://ert-live-bcbs15228.siliconweb.com/media/ert_sports_6/ert_sports_6medium.m3u8) | <img height="20" src="https://i.imgur.com/gebWmAB.png"/> |
| 16  | Euronews Greek Ⓨ | [>](https://www.youtube.com/c/euronewsGreek/live) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Euronews_2022.svg/640px-Euronews_2022.svg.png"/> | EuronewsGreek.fr |
