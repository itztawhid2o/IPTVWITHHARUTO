<h1>Estonia</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | ETV Ⓖ     | [>](http://sb.err.ee/live/etv.m3u8) | <img height="20" src="https://i.imgur.com/5URjPgG.png"/> | ETV.ee |
| 2   | ETV2 Ⓖ    | [>](http://sb.err.ee/live/etv2.m3u8) | <img height="20" src="https://i.imgur.com/fUjGHDa.png"/> | ETV2.ee |
| 3   | ETV+ Ⓖ    | [>](http://sb.err.ee/live/etvpluss.m3u8) | <img height="20" src="https://i.imgur.com/YAubPlU.png"/> | ETVPlus.ee |
| 4   | Riigikogu  | [>](https://riigikogu.babahhcdn.com/bb1027/smil:riigikogu_ch1.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/7uWaZLF.png"/> | Riigikogu.ee |
| 5   | Taevas TV7 | [>](https://vod.tv7.fi/tv7-ee/_definst_/smil:tv7-ee.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/usXedIj.png"/> | TaevasTV7.fi |
| 6   | Life TV Estonia | [>](https://lifetv.bitflip.ee/live/stream2.m3u8) | <img height="20" src="https://i.imgur.com/JhrTB82.png"/> | LifeTV.ee |
| 7   | Life TV Europe | [>](https://lifetv.bitflip.ee/live/stream1.m3u8) | <img height="20" src="https://i.imgur.com/JhrTB82.png"/> | LifeTVEurope.ee |
| 8   | TBN Baltia | [>](http://dc.tbnbaltia.eu:8088/dvr/rewind-21600.m3u8) | <img height="20" src="https://i.imgur.com/rKBaK56.png"/> | TBNBaltia.ee |
