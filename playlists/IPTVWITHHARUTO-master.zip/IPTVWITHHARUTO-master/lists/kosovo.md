<h1>Kosovo</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | RTK 1 | [>](https://ub1doy938d.gjirafa.net/live/Gfsqdsr7FewrYClU3ACEGZvCHktt2wse/zykxzq.m3u8) | <img height="20" src="https://i.imgur.com/KTcWcO6.png"/> | RTK1.xk |
| 2   | RTK 2 | [>](https://ub1doy938d.gjirafa.net/live/Gfsqdsr7FewrYClU3ACEGZvCHktt2wse/zykxz0.m3u8) | <img height="20" src="https://i.imgur.com/g6k6xyO.png"/> | RTK2.xk |
| 3   | RTK 3 | [>](https://ub1doy938d.gjirafa.net/live/Gfsqdsr7FewrYClU3ACEGZvCHktt2wse/zykxzk.m3u8) | <img height="20" src="https://i.imgur.com/Ut9VcT3.png"/> | RTK3.xk |
| 4   | RTK 4 | [>](https://ub1doy938d.gjirafa.net/live/Gfsqdsr7FewrYClU3ACEGZvCHktt2wse/zykxgt.m3u8) | <img height="20" src="https://i.imgur.com/Urm4XDR.png"/> | RTK4.xk |
